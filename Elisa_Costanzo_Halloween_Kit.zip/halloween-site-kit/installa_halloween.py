#!/usr/bin/env python3
"""Adds the one-line Halloween include to every top-level HTML page; safe to rerun."""
from pathlib import Path

root = Path(__file__).resolve().parent
script_tag = '<script src="halloween.js" defer></script>'
if not (root / 'halloween.js').exists():
    raise SystemExit('Errore: manca halloween.js nella cartella.')
found = 0
changed = 0
for path in sorted(root.glob('*.html')):
    found += 1
    html = path.read_text(encoding='utf-8')
    if 'halloween.js' in html:
        print(f'Gia presente: {path.name}')
        continue
    needle = '</head>'
    index = html.lower().find(needle)
    if index < 0:
        print(f'Saltata (head mancante): {path.name}')
        continue
    html = html[:index] + '  ' + script_tag + '\n' + html[index:]
    path.write_text(html, encoding='utf-8')
    changed += 1
    print(f'Aggiornata: {path.name}')
print(f'Pagine trovate: {found}. Pagine modificate: {changed}.')
