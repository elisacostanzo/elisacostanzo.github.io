#!/usr/bin/env python3
"""Removes the Halloween include from every top-level HTML page."""
from pathlib import Path
root = Path(__file__).resolve().parent
for path in sorted(root.glob('*.html')):
    html = path.read_text(encoding='utf-8')
    lines = html.splitlines(keepends=True)
    result = [line for line in lines if '<script src="halloween.js" defer></script>' not in line]
    if len(result) < len(lines):
        path.write_text(''.join(result), encoding='utf-8')
        print(f'Ripristinata: {path.name}')
print('Puoi anche eliminare il file halloween.js.')
